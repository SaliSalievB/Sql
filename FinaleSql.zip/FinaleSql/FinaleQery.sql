SELECT * 
FROM Players 
WHERE team_id = 1;

SELECT home_team_id,
       SUM(CASE WHEN home_score > away_score THEN 1 ELSE 0 END) AS wins,
       SUM(CASE WHEN home_score = away_score THEN 1 ELSE 0 END) AS draws,
       SUM(CASE WHEN home_score < away_score THEN 1 ELSE 0 END) AS losses
FROM Matches
GROUP BY home_team_id;

SELECT TOP 5 * FROM Matches
WHERE home_team_id = 1 OR away_team_id = 1
ORDER BY match_date DESC;

SELECT away_team_id AS team_id, COUNT(*) AS total_matches, SUM(CASE WHEN away_score > home_score THEN 1 ELSE 0 END) AS wins
FROM Matches
GROUP BY away_team_id
HAVING COUNT(*) > 0 AND SUM(CASE WHEN away_score > home_score THEN 1 ELSE 0 END) / COUNT(*) > 0.5;
